
# Veer Fire Safety

This is a static website for Veer Fire Safety, including:

- Homepage
- Navigation Menu
- Courses Page
- Contact Form
- Mobile Responsive Layout

## 🔥 Live Demo (after GitHub Pages is enabled)

After uploading to GitHub and enabling GitHub Pages, your site will be live at:

```
https://yourusername.github.io/veer-fire-safety/
```

## 📁 Folder Structure

```
veer-fire-safety/
├── index.html
├── css/
│   └── style.css
├── images/
│   ├── fire-alarm.jpg
│   └── fireman.png
└── pages/
    ├── courses.html
    └── contact.html
```

## ✅ How to Deploy on GitHub Pages

1. Create a new public GitHub repository
2. Upload everything inside this folder (not the folder itself)
3. Go to `Settings > Pages`
4. Choose `main` branch and `/ (root)`
5. Save – your site is live!
